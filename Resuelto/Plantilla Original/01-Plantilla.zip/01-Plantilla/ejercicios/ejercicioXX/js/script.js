"use strict"

const resultado = document.getElementById("resultado");
console.log({resultado});
console.log(resultado.innerHTML);
resultado.innerHTML = "Estoy mostrando el resultado del ejercicio..."
